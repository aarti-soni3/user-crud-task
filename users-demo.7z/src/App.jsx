import "./App.css";
import UserList from "./Component/UserList";

function App() {
  return (
    <>
      <UserList />
    </>
  );
}

export default App;
